import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/map_location.dart';

class MapView extends StatelessWidget {
  final AppController controller;

  const MapView({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    final selectedLocation = controller.locations[controller.selectedMapIndex];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Irrigation Map',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          const Text(
            'Map view of all sensors with real-time status and affected areas.',
            style: TextStyle(fontSize: 14, color: Color(0xFF5E6F7D)),
          ),
          const SizedBox(height: 18),
          _buildStatusChips(),
          const SizedBox(height: 18),
          Expanded(child: _buildMapStack(context)),
          const SizedBox(height: 18),
          _buildLocationCard(selectedLocation),
          const SizedBox(height: 18),
          _buildSummaryRow(),
        ],
      ),
    );
  }

  Widget _buildStatusChips() {
    final items = [
      _TrendChip(label: 'All', color: const Color(0xFF107C45)),
      _TrendChip(label: 'Good', color: const Color(0xFF24B470)),
      _TrendChip(label: 'Warning', color: const Color(0xFFF1B40F)),
      _TrendChip(label: 'Unsafe', color: const Color(0xFFE63946)),
    ];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: items
            .map(
              (item) => Padding(
                padding: const EdgeInsets.only(right: 10),
                child: item,
              ),
            )
            .toList(),
      ),
    );
  }

  Widget _buildMapStack(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.06),
            blurRadius: 24,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: AspectRatio(
        aspectRatio: 4 / 5,
        child: Stack(
          children: [
            Positioned.fill(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Container(
                  color: const Color(0xFFEFF3F7),
                  child: Center(
                    child: Icon(
                      Icons.map_outlined,
                      size: 120,
                      color: Colors.grey.shade300,
                    ),
                  ),
                ),
              ),
            ),
            ...controller.locations.asMap().entries.map((entry) {
              return Positioned(
                top: entry.value.top * 420,
                left:
                    entry.value.left * MediaQuery.of(context).size.width * 0.84,
                child: GestureDetector(
                  onTap: () {
                    controller.selectMapLocation(entry.key);
                  },
                  child: Column(
                    children: [
                      Container(
                        width: 18,
                        height: 18,
                        decoration: BoxDecoration(
                          color: entry.value.statusColor,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 3),
                          boxShadow: [
                            BoxShadow(
                              color: entry.value.statusColor.withOpacity(0.35),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        entry.value.subtitle,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          shadows: [
                            Shadow(color: Colors.black26, blurRadius: 8),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  Widget _buildLocationCard(MapLocation location) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                location.name,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: location.statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Text(
                  location.subtitle,
                  style: TextStyle(
                    color: location.statusColor,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            location.details,
            style: const TextStyle(fontSize: 14, color: Color(0xFF5E6F7D)),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow() {
    final summaries = [
      _LocationSummary(
        label: 'Active Sensors',
        value: '18',
        color: const Color(0xFF107C45),
      ),
      _LocationSummary(
        label: 'Unsafe Locations',
        value: '2',
        color: const Color(0xFFE63946),
      ),
      _LocationSummary(
        label: 'Good Quality',
        value: '16',
        color: const Color(0xFF24B470),
      ),
    ];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: summaries
          .map(
            (item) => Expanded(
              child: Padding(
                padding: const EdgeInsets.only(right: 8),
                child: item,
              ),
            ),
          )
          .toList(),
    );
  }
}

class _TrendChip extends StatelessWidget {
  final String label;
  final Color color;

  const _TrendChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        label,
        style: TextStyle(color: color, fontWeight: FontWeight.w700),
      ),
    );
  }
}

class _LocationSummary extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _LocationSummary({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(color: Color(0xFF7A8F9B), fontSize: 12),
          ),
          const SizedBox(height: 10),
          Text(
            value,
            style: TextStyle(
              color: color,
              fontSize: 22,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
