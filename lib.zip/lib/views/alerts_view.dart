import 'package:flutter/material.dart';

import '../controllers/app_controller.dart';
import '../models/alert_item.dart';

class AlertsView extends StatefulWidget {
  final AppController controller;

  const AlertsView({super.key, required this.controller});

  @override
  State<AlertsView> createState() => _AlertsViewState();
}

class _AlertsViewState extends State<AlertsView> {
  String selectedFilter = 'All';

  @override
  Widget build(BuildContext context) {
    final alerts = widget.controller.alerts;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Alerts',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          const Text(
            'Real-time alerts when water quality becomes unsafe for irrigation.',
            style: TextStyle(fontSize: 14, color: Color(0xFF5E6F7D)),
          ),
          const SizedBox(height: 18),
          _buildFilterRow(),
          const SizedBox(height: 18),
          Expanded(
            child: ListView(
              children: [
                _buildPrimaryAlert(alerts.first),
                const SizedBox(height: 16),
                ...alerts.skip(1).map((item) => _buildAlertTile(item)).toList(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterRow() {
    final options = ['All', 'Unread', 'Important'];
    return Row(
      children: options.map((option) {
        final isSelected = option == selectedFilter;
        return Padding(
          padding: const EdgeInsets.only(right: 12),
          child: ChoiceChip(
            label: Text(option),
            selected: isSelected,
            selectedColor: const Color(0xFF107C45),
            backgroundColor: const Color(0xFFF4F7FB),
            labelStyle: TextStyle(
              color: isSelected ? Colors.white : const Color(0xFF5E6F7D),
              fontWeight: FontWeight.w600,
            ),
            onSelected: (_) {
              setState(() {
                selectedFilter = option;
              });
            },
          ),
        );
      }).toList(),
    );
  }

  Widget _buildPrimaryAlert(AlertItem item) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFFFFF1F1),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFF5C1C1)),
      ),
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.warning_amber_rounded, color: Color(0xFFE63946)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  item.title,
                  style: const TextStyle(
                    fontWeight: FontWeight.w700,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'Immediate Action Recommended',
            style: TextStyle(color: Colors.red.shade700, fontSize: 13),
          ),
          const SizedBox(height: 16),
          _buildDetailRow('Canal', item.subtitle.split('•').first.trim()),
          _buildDetailRow(
            'Detected At',
            item.subtitle.split('•').skip(1).join('•').trim(),
          ),
          _buildDetailRow(
            'Parameter Triggered',
            item.parameter,
            valueColor: const Color(0xFFE63946),
          ),
          _buildDetailRow(
            'Severity',
            item.severity,
            valueColor: const Color(0xFFE63946),
          ),
          const SizedBox(height: 14),
          const Text(
            'Recommendations:',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          ...?item.details?.map(
            (detail) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Row(
                children: [
                  const Icon(Icons.circle, size: 8, color: Color(0xFFE63946)),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(detail, style: const TextStyle(fontSize: 13)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFFE63946),
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text('View on Map'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE63946),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text('Acknowledge'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildAlertTile(AlertItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                item.title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w700,
                ),
              ),
              _severityChip(item),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            item.subtitle,
            style: const TextStyle(color: Color(0xFF7A8F9B), fontSize: 13),
          ),
          const SizedBox(height: 12),
          Text(
            item.parameter,
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }

  Widget _severityChip(AlertItem item) {
    final color = item.alertType == AlertType.warning
        ? const Color(0xFFF1B40F)
        : const Color(0xFF107C45);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        item.alertType == AlertType.warning ? 'Warning' : 'Info',
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w700,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildDetailRow(String title, String value, {Color? valueColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(color: Color(0xFF7A8F9B), fontSize: 13),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: valueColor ?? const Color(0xFF1D2A3A),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
